import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InstructionsPage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InstructionsPage extends Actor
{
    public InstructionsPage()
    {
        GreenfootImage insIns = new GreenfootImage(800,600);
        insIns.setColor(Color.WHITE);
        insIns.fill();
        insIns.setColor(Color.BLACK);
        insIns.drawString("Instructions :", 100, 100);
        insIns.drawString("- The aim of the game is to avoid obstacles while not letting the soccer balls touch the ground.", 100, 140);
        insIns.drawString("- The obstacles come in various forms like, wet grass, tall grass, slide tackles and banana peels", 100, 160);
        //point system
        insIns.drawString("How the point system works: ", 100, 200);
        insIns.drawString(" Increase Points and Health:", 100, 220);
        insIns.drawString("- Every ball 'headed' is worth 1 point", 100, 240);
        insIns.drawString("- Getting a health pack increases your health by 1" , 100, 260);
        insIns.drawString(" Decrease Points and Health:", 100, 280);
        insIns.drawString("- If you step on the banana peel , you lose 2 points and also lose 1 health", 100, 300);
        insIns.drawString("- If you miss a ball you lose 1 point", 100, 320);
        insIns.drawString("- Slipping on the wet grass is -1 health", 100, 340);
        insIns.drawString("- If you get slide tackled, you lose 2 health", 100, 360);
        //stamina bar
        insIns.drawString("Stamina bar: ", 100, 400);
        insIns.drawString("- You lose stamina as you are in motion ", 100, 420);
        insIns.drawString("- Sliding affects your stamina more heavily ", 100, 440);
        insIns.drawString("- One water bottle fills up your stamina bar ", 100, 460);
        //win, lose and keyboard instructions
        insIns.drawString("- Collect 40 points to win the game ", 400, 420);
        insIns.drawString("- Press the right arrow key to move right and the left key to move left", 400, 440);
        insIns.drawString("- Press the spacebar to jump", 400, 460);
        insIns.drawString("- Hold down the right/left arrow key down with the down key to slide", 400, 480);
        //click anywhere to go back
        GreenfootImage back = new GreenfootImage(200,100);
        back.drawString("Click the 'B' key to go back!", 10, 20);
        back.scale(400,250);
        insIns.drawImage(back, 220,490);
        setImage(insIns);
    }
    /**
     * Act - do whatever the InstructionsPage wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        //to go back to the start screen
        if(Greenfoot.isKeyDown("b")==true)
        {
            getWorld().removeObject(this);
        }
    }    
}
