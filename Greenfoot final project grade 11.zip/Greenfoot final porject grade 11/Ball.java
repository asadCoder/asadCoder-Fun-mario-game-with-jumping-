import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ball here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ball extends Actor
{
    private int vSpeed = 2;
    private boolean remove;
    private boolean scoreAdded = false;

    /**
     * Act - do whatever the Ball wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Ball()
    {
        GreenfootImage ball = new GreenfootImage("ball.png");
        ball.scale(50,50);
        setImage(ball);
        
    }
    public void act() 
    {
        // Add your action code here.
        drop();
        decreasePoints();
        removeIfAtEdge();
        headBall();
        if(remove==true)
        {
            getWorld().removeObject(this);
        }
    }    
    //heading the ball
    private void headBall()
    {
        if(isTouching(Player.class)==true)
        {
            int r = getRotation();
            //turn(270);
            setRotation(r-90);
            vSpeed=-2;
            if(scoreAdded==false)
            {
                ((MyWorld)getWorld()).updateScore(2);
                scoreAdded=true;
            }
        }
    }
    //remove the ball if the ball is at edge
    private void removeIfAtEdge()
    {
      if(isAtEdge()==true)
      {
          remove=true;
      }
    }
    //fall
    private void drop()
    {
        setLocation(getX(), getY()+ vSpeed);
    }
    private void decreasePoints()
    {
        if(getY()==490)
        {
            ((MyWorld)getWorld()).updateScore(-1);
        }
    }
    
}
