import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class Stamina here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Stamina extends Actor
{
    private GreenfootImage[] waterFill = new GreenfootImage[13];
    GreenfootImage sWater = new GreenfootImage(300,100);
    public int counterForStamina = 120;
    public int imageNumber = 12;
    public Stamina()
    {
        //storing the images
        for(int i = 0; i<waterFill.length; i++)
        {
            waterFill[i] = new GreenfootImage("frame_"+i+"_delay-0.02s.gif");
            waterFill[i].scale(30, 40);
        }
        sWater.setColor(Color.WHITE);
        sWater.fillRect(0, 5, 50,20);
        sWater.setColor(Color.BLACK);
        sWater.drawString("Stamina: " , 0,20);
        GreenfootImage water = new GreenfootImage("frame_12_delay-0.02s.gif");
        water.scale(30, 40);
        sWater.drawImage(water, 60, 5);
        setImage(sWater);
    }
    /**
     * Act - do whatever the Stamina wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        gameStop();
    }    
    //stop the game if the stamina is zero
    private void gameStop()
    {
        if(imageNumber<0)
        {
            Greenfoot.stop();
            getWorld().showText("YOU GOT TIRED!", 400, 250);
        }
    }
    //decrasing the stamina over time
    public void decreaseStamina(int add)
    {
        counterForStamina = counterForStamina + add;
        if(counterForStamina<=0)    
        {
            counterForStamina=120;
            sWater.drawImage(waterFill[imageNumber--], 60, 5);
        }
        else if(counterForStamina>=120 && counterForStamina<240)
        {
            imageNumber = imageNumber + 1;
            if(imageNumber>12)
            {
                imageNumber=12;
            }
            sWater.drawImage(waterFill[imageNumber], 60, 5);
        }
    }

}
