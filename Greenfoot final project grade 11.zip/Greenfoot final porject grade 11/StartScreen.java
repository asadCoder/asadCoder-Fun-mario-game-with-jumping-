import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StartScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartScreen extends World
{
    private Instructions insBtn;
    
    private boolean w=false;
    private boolean bts=false;
    /**
     * Constructor for objects of class StartScreen.
     * 
     */
    public StartScreen()
    {    
        // Create a new world with 800x500 cells with a cell size of 1x1 pixels and have no boundaries
        super(800, 500, 1, false); 
        
        //add instructions and start button
        StartGame startBtn = new StartGame();
        addObject(startBtn, 681, 330);
        insBtn = new Instructions();
        addObject(insBtn, 647, 390);
        
        //add instructions about instructions
        StartIns startIns = new StartIns();
        addObject(startIns, 1475, 460);
        
    }
    public void act()
    {
        
    }
   
}
