
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    private GreenfootImage[] playerLeft = new GreenfootImage[8];
    private GreenfootImage[] playerRight = new GreenfootImage[8];
    //player standing still picture
    GreenfootImage playerStanding = new GreenfootImage("player_standing_still.gif");
    //slideing left and right images of player
    GreenfootImage slideRight = new GreenfootImage("slide_right.gif");
    GreenfootImage slideLeft = new GreenfootImage("slide_left.gif");
    
    private static final int SPEED = 4;
    private int moveSpeed=4;
    private int currImg;
    private int delay;  
    //how high the player jumps
    private int jumpStrength = 20;
    //increasing the speed of fall when the player falls after jumping
    private int fallAcceleration = 1;
    //veritcal speed
    private int vSpeed = 0;
    private boolean onGround=true;
    //player already jumped (to make the player jump only once when the space bar is pressed)
    private boolean jumped = false;
    private boolean updateHB = false;
    //counter
    private int c = 20;
    private boolean scoreAdded = false;
    //if it touches an obstacle
    private boolean touchingObstacle = false;
    private int counterToRemove = 40;
    private boolean toRemove=false;
    //if the player is on the move
    private boolean walking=false;
    public Player()
    {
        playerStanding.scale(130,150);
        setImage(playerStanding);
        //reducing the size of the images
        getImage().scale(130,150);
        slideRight.scale(130,150);
        slideLeft.scale(130,150);
        //store the images in an array
        for(int i=0; i < playerLeft.length; i++)
        {
            playerLeft[i] = new GreenfootImage("frame_"+i+"_delay_L.gif");
            playerLeft[i].scale(130,150);
            playerRight[i] = new GreenfootImage("frame_"+i+"_delay_R.gif");
            playerRight[i].scale(130,150);
        }
    }

    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        movement();
        increaseS();
        increaseH();
        sliding();
        jump(); 
        checkFall();
        touchingObstacles();
    }    
    //increase the player's health
    private void increaseH()
    {
        if(isTouching(Healthpack.class))
        {
            ((MyWorld)getWorld()).updateHealthbar(1);
            removeTouching(Healthpack.class);
        }
    }
    //increase stamina 
    private void increaseS()
    {
        if(isTouching(WaterBottle.class))
        {
            ((MyWorld)getWorld()).dStamina(150);
            removeTouching(WaterBottle.class);
        }
    }
    //sliding method
    private void sliding()
    {
        if(Greenfoot.isKeyDown("left")==true && Greenfoot.isKeyDown("down")==true && Greenfoot.isKeyDown("space")==false)
        {
            Greenfoot.playSound("Woosh-C10-www.fesliyanstudios.com.mp3");
            ((MyWorld)getWorld()).dStamina(-2);
            c--;
            if(c>0)
            {
                move(-moveSpeed);
                setImage(slideLeft);
            }
        }
        else if(Greenfoot.isKeyDown("right")==true && Greenfoot.isKeyDown("down")==true && Greenfoot.isKeyDown("space")==false)
        {
            Greenfoot.playSound("Woosh-C10-www.fesliyanstudios.com.mp3");
            ((MyWorld)getWorld()).dStamina(-2);
            c--;
            if(c>0)
            {
                move(moveSpeed);
                setImage(slideRight);
            }
        }
        else
        {
            c = 20;
        }
    }
    //if a player touches an obstacle
    private void touchingObstacles()
    {
        Obstacles o = (Obstacles)getOneIntersectingObject(Obstacles.class);
        //if the player touches the obstacles from the left or right
        Obstacles oT =(Obstacles) getOneObjectAtOffset(20, 50, Obstacles.class);
        Obstacles oT1 =(Obstacles) getOneObjectAtOffset(-20, 50, Obstacles.class);
        if(oT != null || oT1 !=null)
        {
            touchingObstacle = true;
        }
        else
        {
            touchingObstacle = false;
        }
        if( o != null)
        {
            if(touchingObstacle==true)
            {
                Greenfoot.playSound("Ouch-sound-effect.mp3");
                toRemove=true;
                if(o.oIG()==0)
                {
                    moveSpeed=2;
                }
                if(o.oIG()==1 && updateHB == false)
                {
                    ((MyWorld)getWorld()).updateHealthbar(-1);
                    updateHB = true;
                }            
                if(o.oIG()==2 && updateHB == false && scoreAdded==false)
                {
                    ((MyWorld)getWorld()).updateHealthbar(-1);
                    ((MyWorld)getWorld()).updateScore(-2);
                    scoreAdded=true;
                    updateHB = true;
                }
                if(o.oIG()==3 && updateHB==false)
                {
                    ((MyWorld)getWorld()).updateHealthbar(-2);
                    updateHB = true;
                }
            }        
        }
        if(toRemove==true)
        {
            counterToRemove--;
            if(counterToRemove<=0)
            {
                getWorld().removeObject(o); 
            }
        }
        if(isTouching(Obstacles.class)==false)
        {
            scoreAdded=false;
            updateHB=false;
            moveSpeed=4;
            counterToRemove=40;
        }
    }
    //moving the player left and right
    private void movement()
    {
        if(Greenfoot.isKeyDown("left")==true)
        {
            ((MyWorld)getWorld()).dStamina(-1);
            walking = true;
            move(-moveSpeed);
            delay++;
            if(delay == SPEED)
            {
                currImg++;
                if(currImg>=playerLeft.length)
                {
                    currImg=0;
                }
                setImage(playerLeft[currImg]);
                delay=0;
            }
        }
        else if(Greenfoot.isKeyDown("right")==true)
        {
            ((MyWorld)getWorld()).dStamina(-1);
            walking = true;
            move(moveSpeed);
            delay++;
            if(delay == SPEED)
            {
                currImg++;
                if(currImg>=playerRight.length)
                {
                    currImg=0;
                }
                setImage(playerRight[currImg]);
                delay=0;
            }  
        }
        else
        {
            setImage(playerStanding);
            walking=false;
        }
    }
    //check to see if player is above y = 420
    private void checkFall()
    {
        if(onGround==true)
        {
            vSpeed = 0;
        }
        else if(getY()>=420)
        {
            onGround=true;
            jumped = false;
        }
        else
        {
            jumped = true;
            fall();
        }
    }
    //jumping method
    private void jump()
    {
        if(Greenfoot.isKeyDown("space")==true && jumped == false)
        {   
            ((MyWorld)getWorld()).dStamina(-1);
            walking=true;
            onGround=false;
            jumped=true;
            vSpeed = -jumpStrength;
            fall();
        }
        else
        {
            walking=false;
        }
    }
    private void fall()
    {
        vSpeed = vSpeed + fallAcceleration;
        setLocation( getX(), getY() + vSpeed );
    }
}
