import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Instructions here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Instructions extends Actor
{
    private boolean changePage=false;
    private InstructionsPage iP = new InstructionsPage();
    /**
     * Act - do whatever the Instructions wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Instructions()
    {
        GreenfootImage ins = getImage();
        ins.scale(350,80);
    }

    public void act() 
    {
        // Add your action code here.
        instructionsBtnPressed();
    }    
    //if the instructions button is pressed
    private void instructionsBtnPressed()
    {
        if(Greenfoot.mousePressed(this)==true)
        {    
            getWorld().addObject(iP, 400, 250);
        }
    }
    
}
