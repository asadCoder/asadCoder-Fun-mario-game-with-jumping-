import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WaterBottle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WaterBottle extends Actor
{
    public WaterBottle()
    {
        setImage("waterbottle.png");
        getImage().scale(50,40);
    }
    /**
     * Act - do whatever the WaterBottle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
        // Add your action code here.
        //move downwards
        setLocation(getX(), getY()+2);
        if(isAtEdge()==true)
        {
            getWorld().removeObject(this);
        }
    }    
}
