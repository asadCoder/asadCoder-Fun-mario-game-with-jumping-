import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    private Scoreboards score;
    private Scoreboards healthB;
    private Stamina stamina;
    private StartScreen start;

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1); 
        
        //start screen
        start = new StartScreen();
        Greenfoot.setWorld(start);
            
        //add player 
        addObject(new Player(), 400,420);
        
        //add a scoreboard
        score = new Scoreboards();
        addObject(score, 50, 30);
        //add a healthbar
        healthB = new Scoreboards(true);
        addObject(healthB, 160, 70);
        
        //adding stamina
        stamina = new Stamina();
        addObject(stamina, 800, 60);
        
    }
    public void act()
    {

        addBalls();
        addObstacles();
        addBottles();
        addHealth();

    }
  
    //add health packs
    public void addHealth()
    {
        if(healthB.healthR() != 10)
        {
            if(Greenfoot.getRandomNumber(800)<1)
            {
                addObject(new Healthpack(), Greenfoot.getRandomNumber(800), 0);
            }
        }
    }
    //decrease stamina if the person is in motion
    public void dStamina(int add)
    {
        stamina.decreaseStamina(add);
    }
    //spawn waterbottles
    public void addBottles()
    {
        if(Greenfoot.getRandomNumber(700)<1)
        {
            addObject(new WaterBottle(),Greenfoot.getRandomNumber(800), 0);
        }
    }
    //update health
    public void updateHealthbar(int healthTaken)
    {
        healthB.addToHealth(healthTaken);
    }
    //adding obstacles
    public void addObstacles()
    {
        int x = Greenfoot.getRandomNumber(800);
        int r = Greenfoot.getRandomNumber(4);
        Obstacles o = new Obstacles(r);
        if(Greenfoot.getRandomNumber(390)<1)
        {
            addObject(o, x , 460);
        }
    }
    //updating the score
    public void updateScore(int add)
    {
        score.addToScore(add);
    }
    
    public void addBalls()
    {
        int x = Greenfoot.getRandomNumber(800);
        if(Greenfoot.getRandomNumber(200)<1)
        {
            addObject(new Ball(), x, 0);
        }
    }
}
