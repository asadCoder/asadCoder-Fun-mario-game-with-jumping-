import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Scoreboards here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scoreboards extends Actor
{
    private int points = 0;
    private int health = 10;
    
    //the scoreboard (points)
    public Scoreboards()
    {
        GreenfootImage scoreboard = new GreenfootImage(80,30);
        scoreboard.setColor(Color.CYAN);
        scoreboard.fill();
        scoreboard.setColor(Color.BLACK);
        scoreboard.drawString("Score: " + points, 5,20);
        setImage(scoreboard);
    }
    //the health bar
    public Scoreboards(boolean healthbar)
    {
        GreenfootImage hb = new GreenfootImage(300,40);
        hb.setColor(Color.WHITE);
        hb.fillRect(0, 0, 40,20);
        hb.setColor(Color.BLACK);
        hb.drawString("Health:" , 0, 15);
        hb.setColor(Color.GREEN);
        for(int i = 40; i < 240; i+=20)
        {   
            hb.fillRect(i, 0, 20, 20);
        }
        setImage(hb);  

    }
   
    
    /**
       * Act - do whatever the Scoreboards wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public int healthR()
    {
        return health;
    }
    //increasing/decreasing the points of the player
    public void addToScore(int add)
    {
        points=points+add;
        GreenfootImage scoreboard = getImage();
        scoreboard.clear();
        scoreboard.setColor(Color.CYAN);
        scoreboard.fill();
        scoreboard.setColor(Color.BLACK);
        if(points<40 && points>=0)
        {
            scoreboard.drawString("Score: " + points, 5,20);
        }
        else if(points>=40)
        {
            scoreboard.drawString("Score: " + points, 5,20);
            getWorld().showText("YOU WON!", 400, 250);
            Greenfoot.stop();
        }
        if(points<0)
        {          
            scoreboard.drawString("Score: " + points, 5,20);
            getWorld().showText("YOU LOST!", 400, 250);
            Greenfoot.stop();
        }
    }
    //increasing/decreasing the health of the player
    public void addToHealth(int add)
    {
        GreenfootImage hb = new GreenfootImage(300,40);
        health = health + add;
        if(health==10)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.GREEN);
            for(int i = 40; i < 240; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==9)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.GREEN);
            for(int i = 40; i < 220; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==8)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.GREEN);
            for(int i = 40; i < 200; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==7)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.YELLOW);
            for(int i = 40; i < 180; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==6)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.YELLOW);
            for(int i = 40; i < 160; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==5)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.YELLOW);
            for(int i = 40; i < 140; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==4)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.ORANGE);
            for(int i = 40; i < 120; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==3)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.ORANGE);
            for(int i = 40; i < 100; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==2)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.RED);
            for(int i = 40; i < 80; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        if(health==1)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health:" , 0, 15);
            hb.setColor(Color.RED);
            for(int i = 40; i < 60; i+=20)
            {   
                hb.fillRect(i, 0, 20, 20);
            }
            setImage(hb);
        }
        //if health is 0, stop the game
        if(health<=0)
        {
            hb.setColor(Color.WHITE);
            hb.fillRect(0, 0, 40,20);
            hb.setColor(Color.BLACK);
            hb.drawString("Health: 0" , 0, 15);
            getWorld().showText("YOU GOT INJURED!", 400, 250);
            setImage(hb);
            Greenfoot.stop();
        }        
    }
}
