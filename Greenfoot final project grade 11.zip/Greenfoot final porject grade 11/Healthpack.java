import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Healthpack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Healthpack extends Actor
{
    public Healthpack()
    {   
        getImage().scale(50,40);
    }
    /**
     * Act - do whatever the Healthpack wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        setLocation(getX(),getY()+2);
        if(isAtEdge())
        {
            remove();
        }
    }    
    private void remove()
    {
        getWorld().removeObject(this);
    }
}
