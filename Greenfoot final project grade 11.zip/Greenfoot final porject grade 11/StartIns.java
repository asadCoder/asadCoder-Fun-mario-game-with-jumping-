import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StartIns here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartIns extends Actor
{
    /**
     * Act - do whatever the StartIns wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public StartIns()
    {
        //instructions about instructions
        GreenfootImage startIns = new GreenfootImage(620,100);
        startIns.setColor(Color.WHITE);
        startIns.drawString("Click on the Instructions button for Instructions and on the Start button to start playing your game!", 100, 80);
        startIns.scale(1350, 100);
        setImage(startIns);
    }
    public void act() 
    {
        // Add your action code here.
        //move the instructions from right to left and do it again if it disapears fully
        move(-2);
        if(getX()<-660)
        {
            setLocation(getX()+1900, getY());
        }
    }    
}
