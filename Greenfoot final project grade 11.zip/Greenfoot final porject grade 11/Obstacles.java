import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Obstacle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Obstacles extends Actor
{
    //obstacle in Game
    private int oInGame;
    private boolean inGame;
    private int counterToRemove = 50;
    private boolean toRemove=false;
    /**
     * Act - do whatever the Obstacle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    public Obstacles()
    {
        
    }
    public Obstacles(int r)
    {
        //set the images of the the obstacles
        if(r==0)
        {
            setImage("tall_grass.png");
            getImage().scale(90,60);
            oInGame=0;
        }
        if(r==1)
        {
            setImage("wet_grass.png");
            getImage().scale(60,30);
            oInGame=1;
        }
        if(r==2)
        {
            setImage("banana_peel_rd.jpg");
            getImage().scale(50,30);
            oInGame=2;
        }
        else if(r==3)
        {
            setImage("slide_tackle.png");
            getImage().scale(70,60);
            oInGame=3;
        }
    }
    public void act() 
    {
        // Add your action code here.
        removeITO();
    }    
    //remove if its touching another obstacle
    private void removeITO()
    {
        if(isTouching(Obstacles.class))
        {
            remove();
        }
    }
    private void remove()
    {
        getWorld().removeObject(this);
    }
    //return the obstacle number
    public int oIG()
    {
        return oInGame;
    }
}
